package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;


public class MailAuthenticator2014302580120 extends Authenticator {
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;

    /**
     * 初始化邮箱和密码
     */
    public MailAuthenticator2014302580120() {
        username = "15927507480@163.com";
        password = "zhangyc";
        
    }

    /**
     * @return password
     */
    String getPassword() {
        return password;
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username, password);
    }

    /**
     * @return password
     */
    String getUsername() {
        return username;
    }
}
