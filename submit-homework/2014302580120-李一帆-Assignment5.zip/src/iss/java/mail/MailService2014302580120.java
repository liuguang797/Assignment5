package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class MailService2014302580120 implements IMailService {
	
	/**
     * 接收邮件的props文件
     */
    private final transient Properties props = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private transient MailAuthenticator2014302580120 authenticator;

    /**
     * 邮箱session
     */
    private transient Session session;
    
    /**
     * 邮件数目计数器
     */
    private int lastNum = 0;

	

	@Override
	/**
     * 初始化并连接所有的邮件服务器
     * @throws MessagingException 初始化或连接异常
     */
	public void connect() throws MessagingException {
		String imapHostName = "imap.163.com";
		String smtpHostName = "smtp.163.com";
		init(imapHostName, smtpHostName);
		System.out.println("Connect succeed!");
	}

	@Override
	/**
     * 发送单封邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// 创建mime类型邮件
        final MimeMessage message = new MimeMessage(session);
        // 设置发信人
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        // 设置收件人
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // 发送
        Transport.send(message);
	}

	
	@Override
	/**
     * 询问服务器是否有新邮件到达
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */
	public boolean listen() throws MessagingException {
		Store store =session.getStore();
    	store.connect();
    	
    	Folder folder = store.getFolder("inbox");
    	folder.open(Folder.READ_ONLY);	
    	int messagesNum = folder.getMessageCount();
    	folder.close(false);
    	store.close();
    	if(messagesNum > lastNum){
    		lastNum = messagesNum;
    		return true;
    	}else {
    		lastNum = messagesNum;
    		return false;
    	}
    	
	}

	@Override
	/**
     * 接收自动回复的内容，并转换为字符串
     * 注：用你能想到的任意方法寻找回复邮件均可，并不一定要用到这两个参数
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		Store store = session.getStore();
        store.connect();
        // 获得邮箱内的邮件夹Folder对象，以"只读"打开
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);
		int m = folder.getMessageCount();
		Message message = folder.getMessage(m);
		String result = "发送人：" + sender + "\n"+ "主题：" + subject + "\n" + "发信人：" + message.getFrom().toString() + "\n" + "邮件内容：" + message.getContent().toString();
		folder.close(false);
        store.close();
		return result;
	}
	
	
	/**
	 * 初始化并连接所有的邮件服务器
     * @throws MessagingException 初始化或连接异常
	 * @param imapHostName
	 * @param smtpHostName
	 */
	private void init(String imapHostName, String smtpHostName) throws MessagingException {
		
    	props.put("mail.store.protocol", "imap");
    	props.put("mail.imap.host", "imap.163.com");
    	
    	props.setProperty("mail.smtp.auth", "true");
    	props.setProperty("mail.transport.protocol", "smtp");  
    	props.setProperty("mail.smtp.host", "smtp.163.com");
        authenticator = new MailAuthenticator2014302580120();
        session = Session.getInstance(props,authenticator);
	}
}
